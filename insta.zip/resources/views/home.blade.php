<x-app>
    <div class="container">
        <h1>{{$user->username}}</h1>
    </div>
</x-app>


    
